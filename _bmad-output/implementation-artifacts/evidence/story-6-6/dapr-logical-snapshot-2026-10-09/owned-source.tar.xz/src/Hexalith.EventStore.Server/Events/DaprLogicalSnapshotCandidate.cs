using System.Security.Cryptography;
using Hexalith.EventStore.Client.Events;
using Hexalith.EventStore.Contracts.Events;

namespace Hexalith.EventStore.Server.Events;
/// <summary>Owns an admitted private snapshot candidate without granting any replay continuation or command authority.</summary>
internal sealed class DaprLogicalSnapshotCandidate : IDisposable
{
    private ImmutablePayload? _state;
    private DaprLogicalResponseOwner? _witness;
    private DaprLogicalReplayAnchorOrigin? _origin;
    private EventBufferBudget? _partition;
    private EventBufferReservation? _decoding;
    private Func<CancellationToken, Task>? _fence;
    private byte[]? _sourcePin;
    private byte[]? _witnessPin;
    private readonly CancellationToken _originatingToken;
    /// <summary>Takes exclusive private storage and retained working ownership after the final actual fence.</summary>
    internal DaprLogicalSnapshotCandidate(ImmutablePayload state, DaprLogicalResponseOwner witness, DaprLogicalReplayAnchorOrigin origin, EventBufferBudget partition, EventBufferReservation decoding, long coveredSequence, long target, byte[] sourcePin, byte[] witnessPin, CancellationToken originatingToken, Func<CancellationToken, Task> fence)
    {
        _state = state;
        _witness = witness;
        _origin = origin;
        _partition = partition;
        _decoding = decoding;
        _fence = fence;
        _sourcePin = sourcePin;
        _witnessPin = witnessPin;
        _originatingToken = originatingToken;
        CoveredSequence = coveredSequence;
        TargetSequence = target;
        StartSequence = DaprLogicalSnapshotCodec.TailStart(coveredSequence);
    }

    /// <summary>Gets the witnessed covered sequence; it is not a committed page pointer.</summary>
    internal long CoveredSequence { get; }
    /// <summary>Gets the original immutable requested target.</summary>
    internal long TargetSequence { get; }
    /// <summary>Gets the candidate tail start without incrementing long.MaxValue.</summary>
    internal long StartSequence { get; }
    /// <summary>Gets whether the exact head snapshot proposes zero tail events.</summary>
    internal bool HasZeroTail => CoveredSequence == TargetSequence;

    /// <summary>Gets canonical private bytes within this candidate's owned lifetime.</summary>
    internal IReadOnlyPayload CanonicalState
    {
        get
        {
            _originatingToken.ThrowIfCancellationRequested();
            return _state ?? throw new ObjectDisposedException(nameof(DaprLogicalSnapshotCandidate));
        }
    }

    /// <summary>Rechecks actual pair, completed history and local pins before a future consumer can use this candidate.</summary>
    internal Task RequireCurrentAsync(CancellationToken token)
    {
        _originatingToken.ThrowIfCancellationRequested();
        return (_fence ?? throw new ObjectDisposedException(nameof(DaprLogicalSnapshotCandidate)))(token);
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        _fence = null;
        byte[]? source = Interlocked.Exchange(ref _sourcePin, null);
        byte[]? witness = Interlocked.Exchange(ref _witnessPin, null);
        if (source is not null)
        {
            CryptographicOperations.ZeroMemory(source);
        }

        if (witness is not null)
        {
            CryptographicOperations.ZeroMemory(witness);
        }

        Interlocked.Exchange(ref _state, null)?.Dispose();
        Interlocked.Exchange(ref _witness, null)?.Dispose();
        Interlocked.Exchange(ref _origin, null)?.Dispose();
        Interlocked.Exchange(ref _decoding, null)?.Dispose();
        Interlocked.Exchange(ref _partition, null)?.Dispose();
    }
}
