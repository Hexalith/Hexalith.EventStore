using System.Security.Cryptography;

using Hexalith.EventStore.Contracts.Events;

namespace Hexalith.EventStore.Client.Events;

/// <summary>Uses an explicitly supplied current CLR type and serializer without CLR name resolution.</summary>
/// <remarks>Only a source-authenticated, schema/identity-validated effective payload may enter this local binding.</remarks>
internal sealed class RegisteredCurrentEventDeserializer
{
    private readonly Type _currentType;
    private readonly Func<IReadOnlyPayload, CancellationToken, object> _deserialize;
    private readonly EventImplementationBinding _serializer;
    private readonly byte[] _typeAssemblyHash;
    private readonly EventManagedArtifactExecutionBinding? _typeExecutionBinding;

    /// <summary>Admits an explicit type and callable with implementation-owned canonical options.</summary>
    internal RegisteredCurrentEventDeserializer(Type currentType, string serializerId,
        Func<IReadOnlyPayload, CancellationToken, object> deserialize, ReadOnlyMemory<byte> canonicalOptions,
        IReadOnlyList<EventOptionRule> optionSchema, Func<ReadOnlyMemory<byte>>? runtimeOptions = null,
        EventManagedArtifactExecutionBinding? serializerExecutionBinding = null,
        EventManagedArtifactExecutionBinding? currentTypeExecutionBinding = null,
        EventManagedArtifactExecutionBinding? runtimeOptionsExecutionBinding = null)
    {
        ArgumentNullException.ThrowIfNull(currentType);
        ArgumentNullException.ThrowIfNull(deserialize);
        _currentType = currentType;
        _deserialize = deserialize;
        _serializer = new EventImplementationBinding(serializerId, deserialize, canonicalOptions, optionSchema, runtimeOptions,
            serializerExecutionBinding, runtimeOptionsExecutionBinding);
        _typeExecutionBinding = currentTypeExecutionBinding;
        if (currentTypeExecutionBinding is not null)
        {
            _typeAssemblyHash = currentTypeExecutionBinding.CopyHashForAssembly(currentType.Assembly);
            return;
        }

        if (string.IsNullOrEmpty(currentType.Assembly.Location))
        {
            throw new ArgumentException("A current type assembly file must be resolvable.", nameof(currentType));
        }

        using FileStream stream = File.OpenRead(currentType.Assembly.Location);
        _typeAssemblyHash = SHA256.HashData(stream);
    }

    /// <summary>Checks immutable D/V bindings without invoking serializer or runtime settings callbacks.</summary>
    internal void RequireDescriptor(EventDomainRegistry registry, string canonicalType,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(registry);
        cancellationToken.ThrowIfCancellationRequested();
        registry.RequireActive(cancellationToken);
        registry.CapabilityLoss.RequireNoObservedLoss();
        _serializer.RequireCapabilityScope(registry.CapabilityLoss);
        _typeExecutionBinding?.RequireCapabilityScope(registry.CapabilityLoss);
        _typeExecutionBinding?.RequireBoundAssembly(_currentType.Assembly);
        EventRegistryRow current = registry.Rows.Single(row => row.Tag == 0x44
            && string.Equals(row.GetTextKey(1), canonicalType, StringComparison.Ordinal));
        if (!string.Equals(current.GetTextField(3), _currentType.AssemblyQualifiedName, StringComparison.Ordinal)
            || !_typeAssemblyHash.AsSpan().SequenceEqual(current.GetEncodedField(4)))
        {
            throw new InvalidOperationException("CapabilityMismatch: current CLR type is not the explicitly allow-listed D binding.");
        }

        _serializer.RequireDeclaredFields(registry.GetVersion(canonicalType, current.GetIntField(2)), 4);
        cancellationToken.ThrowIfCancellationRequested();
        registry.CapabilityLoss.RequireNoObservedLoss();
    }

    /// <summary>Checks D/V bindings before invoking the serializer and requires the exact allow-listed output type.</summary>
    internal object Deserialize(EventDomainRegistry registry, string canonicalType, IReadOnlyPayload effectivePayload,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(effectivePayload);
        RequireDescriptor(registry, canonicalType, cancellationToken);
        _serializer.RequireFields(registry.GetVersion(canonicalType, registry.GetCurrentVersion(canonicalType)), 4, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        registry.CapabilityLoss.RequireNoObservedLoss();
        using var lease = new InvocationPayloadLease(effectivePayload, cancellationToken);
        object value = _deserialize(lease, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        registry.CapabilityLoss.RequireNoObservedLoss();
        if (value is null || value.GetType() != _currentType)
        {
            throw new InvalidOperationException("UpcasterContractViolation: serializer returned a different current CLR type.");
        }

        return value;
    }

    /// <summary>Fences the options getter and serializer separately, expiring the borrowed view before source readback.</summary>
    internal async ValueTask<object> DeserializeAsync(EventDomainRegistry registry, string canonicalType,
        IReadOnlyPayload effectivePayload, Func<CancellationToken, Task>? sourceFence, CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(effectivePayload);
        Task FenceAsync(CancellationToken cancellation) => EventCallbackFence.RequireAsync(registry, sourceFence, cancellation,
            () => RequireDescriptor(registry, canonicalType, cancellation)).AsTask();
        await FenceAsync(token).ConfigureAwait(false);
        await _serializer.RequireFieldsAsync(registry.GetVersion(canonicalType, registry.GetCurrentVersion(canonicalType)),
            4, FenceAsync, token, () => RequireDescriptor(registry, canonicalType, token)).ConfigureAwait(false);
        await FenceAsync(token).ConfigureAwait(false);
        object value;
        using (var lease = new InvocationPayloadLease(effectivePayload, token))
        {
            try { value = _deserialize(lease, token); }
            finally { token.ThrowIfCancellationRequested(); }
        }

        await FenceAsync(token).ConfigureAwait(false);
        if (value is null || value.GetType() != _currentType)
        {
            throw new InvalidOperationException("UpcasterContractViolation: serializer returned a different current CLR type.");
        }

        return value;
    }
}
